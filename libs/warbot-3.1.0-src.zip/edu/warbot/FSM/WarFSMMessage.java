package edu.warbot.FSM;

public class WarFSMMessage {
	
	public static final String enemyBaseHere = "enemyBaseHere";
	public static final String enemyTankHere = "enemyTankHere";
	
	public static final String whereAreYou = "whereAreYou";
	public static final String here = "here";
	
	public static final String baseIsAttack = "baseIsAttack";
	
	public static final String foodHere = "foodHere";
	

}
