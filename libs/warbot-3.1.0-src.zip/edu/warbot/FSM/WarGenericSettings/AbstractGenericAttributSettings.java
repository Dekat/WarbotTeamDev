package edu.warbot.FSM.WarGenericSettings;

public class AbstractGenericAttributSettings {

}
