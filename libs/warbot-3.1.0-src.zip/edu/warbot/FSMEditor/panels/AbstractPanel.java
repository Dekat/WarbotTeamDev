package edu.warbot.FSMEditor.panels;

import javax.swing.*;

public class AbstractPanel extends JPanel{

	private static final long serialVersionUID = 1L;

}
