package edu.warbot.FSMEditor.settings;

public enum EnumAction {
	WarActionAttaquer,
	WarActionChercherBase,
	WarActionChercherNouriture,
	WarActionCreateUnit,
	WarActionDefendre,
	WarActionDontMove,
	WarActionFuire,
	WarActionHeal,
	WarActionIdle,
	WarActionRaporterNouriture,
	WarActionWiggle
}
