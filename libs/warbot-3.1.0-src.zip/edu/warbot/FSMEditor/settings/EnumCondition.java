package edu.warbot.FSMEditor.settings;

public enum EnumCondition {
	WarConditionTimeOut,
	WarConditionAttributCheck,
	WarConditionBooleanCheck,
	WarConditionMessageChecker,
	FWarConditionPerceptAttributCheck,
	WarConditionPerceptCounter
}
