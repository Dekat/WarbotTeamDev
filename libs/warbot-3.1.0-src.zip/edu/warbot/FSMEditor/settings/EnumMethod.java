package edu.warbot.FSMEditor.settings;

public enum EnumMethod {
	getHealth,
	getBagSize,
	getNbElementsInBag,
	isBagFull,
	isBagEmpty,
	isFullLife,
	isLowLife
}
