package edu.warbot.FSMEditor.settings;

public enum EnumOperand {
	eg,
	dif,
	sup,
	inf,
	infEg,
	supEg
}
