package edu.warbot.FSMEditor.settings;


public enum EnumPlan {
	WarPlanAttaquer,
	WarPlanBeSecure,
	WarPlanCreateUnit,
	WarPlanDefendre,
	WarPlanHealer,
	WarPlanIdle,
	WarPlanRamasserNouriture,
	WarPlanWiggle,
	WarPlanPatrouiller
}
