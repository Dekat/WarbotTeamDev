package edu.warbot.FSMEditor.settings;

public enum EnumReflexe {
	WarReflexeAnswerMessage,
	WarReflexeWarnWithCondition
}
