package edu.warbot.agents.actions;


public interface CreatorActions {

	public static String ACTION_CREATE = "create";
	
	public String create();
}
