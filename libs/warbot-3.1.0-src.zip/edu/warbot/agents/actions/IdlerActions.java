package edu.warbot.agents.actions;

public interface IdlerActions {

    public static final String ACTION_IDLE = "idle";

    public String idle();

}
