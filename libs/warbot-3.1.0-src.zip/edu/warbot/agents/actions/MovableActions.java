package edu.warbot.agents.actions;

public interface MovableActions {

	public static String ACTION_MOVE = "move";
	
	public String move();
}
