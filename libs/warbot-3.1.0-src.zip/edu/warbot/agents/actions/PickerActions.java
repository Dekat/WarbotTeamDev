package edu.warbot.agents.actions;

public interface PickerActions {

	public static String ACTION_TAKE = "take";
	
	public String take();
}
