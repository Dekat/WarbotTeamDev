package edu.warbot.agents.enums;

public enum WarAgentCategory {
	Building,
	Soldier,
	Worker,
	Projectile,
	Resource
}
