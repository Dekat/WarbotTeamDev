package edu.warbot.brains.adapters;

import edu.warbot.agents.agents.WarBase;
import edu.warbot.brains.CreatorWarAgentAdapter;

public class WarBaseAdapter extends CreatorWarAgentAdapter {

	public WarBaseAdapter(WarBase agent) {
		super(agent);
	}

}
