package edu.warbot.brains.adapters;

import edu.warbot.agents.agents.WarExplorer;
import edu.warbot.brains.MovableWarAgentAdapter;

public class WarExplorerAdapter extends MovableWarAgentAdapter {

	public WarExplorerAdapter(WarExplorer agent) {
		super(agent);
	}

}
