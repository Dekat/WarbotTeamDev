package edu.warbot.brains.capacities;

public interface Agressive {

	public boolean isReloaded();
	public boolean isReloading();
	
}
