package edu.warbot.brains.capacities;

public interface Alive extends CommonCapacities {

	public int getHealth();
	public int getMaxHealth();

}
