package edu.warbot.brains.capacities;

public interface Movable {

	public boolean isBlocked();
	public double getSpeed();
	
}
