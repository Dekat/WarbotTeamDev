package edu.warbot.brains.capacities;

public interface Picker {

}
