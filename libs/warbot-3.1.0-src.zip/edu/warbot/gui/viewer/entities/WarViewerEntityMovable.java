package edu.warbot.gui.viewer.entities;

public interface WarViewerEntityMovable {
	void animateMoving();
}
